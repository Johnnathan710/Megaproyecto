﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenBCI_GUI
{
    public partial class Form2 : Form
    {
        string path;
        string path1;
        string path2;
        int cont = 0;
        bool cambio = false;
        Form1 f = new Form1();
        Boolean State = false;

        public Form2()
        {
            InitializeComponent();
        
        }

        public void GetState(Boolean s)
        {
            State = s;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            pictureBox18.Visible = false;
            pictureBox19.Visible = false;
            Random random = new Random();
            Random random2 = new Random();
            Random random3 = new Random();
            int cont = 0;
            int c1 = random.Next(1,5); // cantidad de bloques mostrados
            int c2 = random2.Next(0, 100); // para los primeros 10 bloques
            int c3 = random3.Next(0, 100); // para los bloques restantes
            while(cont <= c1)
            {
                if (c2 > 95)
                {
                    cont++;
                    pictureBox3.Visible = true;
                }
                if (c2 < 5)
                {
                    cont++;
                    pictureBox7.Visible = true;
                }
                if(c2 < 50)
                {
                    cont++;
                    int c4 = random.Next(1, 4);
                    if (c4 == 1){
                        pictureBox4.Visible = true;
                    }
                    if (c4 == 2)
                    {
                        pictureBox6.Visible = true;
                    }
                    if (c4 == 3)
                    {
                        pictureBox9.Visible = true;
                    }
                    if (c4 == 4)
                    {
                        pictureBox11.Visible = true;
                    }
                }
                if (c2 > 50)
                {
                    cont++;
                    int c4 = random.Next(1, 4);
                    if (c4 == 1)
                    {
                        pictureBox5.Visible = true;
                    }
                    if (c4 == 2)
                    {
                        pictureBox10.Visible = true;
                    }
                    if (c4 == 3)
                    {
                        pictureBox8.Visible = true;
                    }
                    if (c4 == 4)
                    {
                        pictureBox14.Visible = true;
                    }

                }
                if (c3 > 95)
                {
                    cont++;
                    pictureBox16.Visible = true;
                }
                if (c3 < 0.5)
                {
                    cont++;
                    pictureBox15.Visible = true;
                }
                if (c3 < 50)
                {
                    cont++;
                    int c4 = random2.Next(1, 3);
                    if (c4 == 1)
                    {
                        pictureBox18.Visible = true;
                    }
                    if (c4 == 2)
                    {
                        pictureBox15.Visible = true;
                    }
                    if (c4 == 3)
                    {
                        pictureBox19.Visible = true;
                    }
                }
                if (c3 > 50)
                {
                    cont++;
                    int c4 = random3.Next(1, 2);
                    if (c4 == 1)
                    {
                        pictureBox13.Visible = true;
                    }
                    if (c4 == 2)
                    {
                        pictureBox12.Visible = true;
                    }
                }
            }
            


            if (Form1.Status6 == true)
            {
                if (timer1.Interval >= 500){
                    timer1.Interval -= 50;
                }
                State = true;
            }
            else
            {
                if(timer1.Interval <= 5000){ 
                timer1.Interval += 50;
                }
                State = false;
            }
            label1.Text = Form1.Status6.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            label1.Text = Form1.Status6.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            if (DialogResult.OK == file.ShowDialog())
            {
                String x;
                cont++;
                path = file.FileName;
                pictureBox1.ImageLocation = path;
                //windowsmediaplayer.Ctlcontrols.play();
            }
        }
    }
}
