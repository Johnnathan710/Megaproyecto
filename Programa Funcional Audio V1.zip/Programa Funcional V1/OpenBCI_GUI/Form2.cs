﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenBCI_GUI
{
    public partial class Form2 : Form
    {
        string path;
        string path1;
        string path2;
        int cont = 0;
        bool cambio = false;
        Form1 f = new Form1();
        Boolean State = false;

        public Form2()
        {
            InitializeComponent();
        
        }

        public void GetState(Boolean s)
        {
            State = s;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            if (DialogResult.OK == file.ShowDialog())
            {
                String x;
                cont++;
                path = file.FileName;
                windowsmediaplayer.URL = path;
                //windowsmediaplayer.Ctlcontrols.play();
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void resumeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            windowsmediaplayer.Ctlcontrols.play();
        }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            windowsmediaplayer.Ctlcontrols.pause();
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            windowsmediaplayer.Ctlcontrols.stop();
        }

        private void adelantarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            windowsmediaplayer.Ctlcontrols.fastForward();
        }

        private void atrasarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            windowsmediaplayer.Ctlcontrols.fastReverse();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Form1.Status6 == true)
            {
                State = true;
                windowsmediaplayer.Ctlcontrols.play();
            }
            else
            {
                State = false;
                windowsmediaplayer.Ctlcontrols.pause();
            }
            label1.Text = Form1.Status6.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            label1.Text = Form1.Status6.ToString();
        }
    }
}
