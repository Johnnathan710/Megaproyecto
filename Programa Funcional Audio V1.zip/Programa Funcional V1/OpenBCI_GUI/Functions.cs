﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
// Utilizada para generar las señales sinusoidales. 
using MathNet.Numerics;
// Usada para realizar la FFT
using MathNet.Numerics.IntegralTransforms;
// para los números complejos
using System.Numerics;
// para generar las graficas
using System.Windows.Forms.DataVisualization.Charting;

namespace OpenBCI_GUI
{
    class Functions
    {
        //variables
        public static int notch = 0;
        public static int standard = 0;

        public static int alpha_up = 12; //valores obtenidos de https://en.wikipedia.org/wiki/Beta_wave
        public static int alpha_low = 8;
        public static int beta_up = 30;
        public static int beta_low = 13;
        public static int delta_up = 3;
        public static int delta_low = 0;
        public static int theta_up  = 7;
        public static int theta_low = 4;
        public static int gamma_up = 100;
        public static int gamma_low = 32;
        public static int rms_up = 16;
        public static int rms_low = 13;
        public static int mbeta_up = 17;
        public static int mbeta_low = 20;
        public static int hbeta_up = 21;
        public static int hbeta_low = 28;

        public static int contch = 8; //Contador de canales

        public static double[] b = { 1, 1, 1, 1, 1 }; //arrays necesarios para aplicar los filtros, 
        public static double[] a = { 1, 1, 1, 1, 1 }; // a y b son para filtros pasa banda y a2 y b2 para filtros notch
        public static double[] b2 = { 1, 1, 1, 1, 1 };
        public static double[] a2 = { 1, 1, 1, 1, 1 };

        static double[,] prev_x_notch = new double[8, 5];  //arrays de doubles para aplicar los filtros tipos notch y los pasabanda
        static double[,] prev_y_notch = new double[8, 5];
        static double[,] prev_x_standard = new double[8, 5];
        static double[,] prev_y_standard = new double[8, 5];

        static double[] ConvertedData = new double[12]; // Array de doubles para almacenar la conversión
        private static int localByteCounter = 0; // contador del número de byte
        private static int localChannelCounter = 0; // contador del canal de entrada
        private static int PACKET_readstate = 0; // estado de la electura
        private static byte[] localAdsByteBuffer = { 0, 0, 0 }; // array de bytes para agregar al buffer
        private static byte[] localAccelByteBuffer = { 0, 0 };  // array de bytes para el buffer

        //Función para realizar conversiones 
        public static int Bit16ToInt32(byte[] byteArray) // función para converstir los bytes de entrada de 16bit a un int32
        {
            int result = (
              ((0xFF & byteArray[0]) << 8) |
               (0xFF & byteArray[1])
              ); // la operanción es (1111 1111 AND Byte No.1 de la entrada) con un left shift de 8 casiilas
            // OR (1111 1111 AND  Byte No.2 de la entrada); el resultado se almacena en el int32 Result
            if ((result & 0x00008000) > 0) // condción No.1 (se revisa solo el primer bit, para ver si es mayor que 0
            {
                result = (int)((uint)result | (uint)0xFFFF0000); // operación es OR con 16 bits de 1's y 16 de 0's, con el resultado

            }
            else // si no se cumple
            {
                result = (int)((uint)result & (uint)0x0000FFFF); // se toman solo los ultimos 16 bits, ya que se hace un AND con 16 bits 0's y 16 bits 1's
            }
            return result; // retorno del valor
        }

        public static int Bit24ToInt32(byte[] byteArray) // función similar para pasar de 24 bits a 32 bits
        {
            int result = (
                 ((0xFF & byteArray[0]) << 16) |  // or del primer byte(corrido 16 espacios) con el segundo byte (corrido 8 espacios) y el utlimo byte
                 ((0xFF & byteArray[1]) << 8) |
                 (0xFF & byteArray[2])
               );
            if ((result & 0x00800000) > 0) // se revisa si el primer byte es mayor o menor que cero
            {
                result = (int)((uint)result | (uint)0xFF000000); // si se da este caso se hace un or para agregar el byte restante
            }
            else
            {
                result = (int)((uint)result & (uint)0x00FFFFFF); // se agrega un byte de 0's
            }
            return result;
        }


        // función de interpretación
        public static double[] interpretBinaryStream(byte actbyte)
        {
            bool flag_copyRawDataToFullData = false; // bandera de proceso de conversión completo

            switch (PACKET_readstate) // Ciclo que siguen los datos para ser convertidos
            {
                case 0: //inicio del proctocolo de comunicación
                    if (actbyte == 0xC0)
                    {          // buscando el inicio del paquete
                        PACKET_readstate++;
                    }
                    break;
                case 1:
                    if (actbyte == 0xA0)
                    {          // buscando el inicio del paquete
                        PACKET_readstate++;
                    }
                    else
                    {
                        PACKET_readstate = 0;
                    }
                    break; // si se cumplen ambos, se procede a la siguiente fase
                case 2:
                    localByteCounter = 0; // se está analizando el primer byte
                    localChannelCounter = 0; // el primero canal
                    ConvertedData[localChannelCounter] = actbyte; // se recibe la data que está en el byte actual
                    localChannelCounter++; // se aumenta el contador de canal y el estado de lectura
                    PACKET_readstate++;
                    break;
                case 3:
                    localAdsByteBuffer[localByteCounter] = actbyte;  // en esta fase se leen los siguientes tres canales
                    localByteCounter++;
                    if (localByteCounter == 3) // cuando ya se contaron 3 bytes se procede a....
                    {
                        ConvertedData[localChannelCounter] = Bit24ToInt32(localAdsByteBuffer); // convertir estos tres bytes a un int32
                        localChannelCounter++; // se aumenta el contador de canales
                        if (localChannelCounter == 9) // cuando ya se contaron los 8 canales
                        {
                            PACKET_readstate++; // se puede pasar al siguiente estado, y se reinicia el contador de bytes
                            localByteCounter = 0;
                        }
                        else // si esto no se cumple solo se reinicia el contador de bytes
                        {
                            localByteCounter = 0;
                        }
                    }
                    break;
                case 4: // fase 5
                    localAccelByteBuffer[localByteCounter] = actbyte; // se alamacena el byte actual en el array del buffer
                    localByteCounter++; // se aumenta el contador de bytes
                    if (localByteCounter == 2) // al llegar al segundo se puede utilizar la función de 16bits a 32 bits
                    {
                        ConvertedData[localChannelCounter] = Bit16ToInt32(localAccelByteBuffer); //se alamacenan los datos convertidos
                        localChannelCounter++; // se aumenta el contador de canales
                        if (localChannelCounter == 12) // hasta llegar a los 12 canales
                        {
                            PACKET_readstate++; // si esto se cumple se reinicia el contador de bytes y se procede a la ultima fase
                            localByteCounter = 0;
                        }
                        else
                        {
                            localByteCounter = 0;
                        }
                    }
                    break;
                case 5: // se verifica que entre el byte final del protocolo
                    if (actbyte == 0xC0)
                    {
                        flag_copyRawDataToFullData = true; // se enciende la bandera 
                        PACKET_readstate = 1; //se establece el valor uno para seguir con la comunicación
                    }
                    else
                    {
                        PACKET_readstate = 0; // si hay un problema se reunicia el protocolo
                    }

                    break;
                default:
                    PACKET_readstate = 0;
                    break;
            }

            if (flag_copyRawDataToFullData) // si se cumple la condición de la bandera, se procede a enviar los datos convertidos
            {
                flag_copyRawDataToFullData = false;
                return ConvertedData;
            }
            else
            {
                return null;
            }
        }


        //Aplicación de filtros
        public static double filterIIR(double[] a2, double[] b2, double[] a, double[] b, double data, int nrk)
        {
            for (int j = 5 - 1; j > 0; j--)//actualización de los filtros previos
            {
                prev_x_notch[nrk, j] = prev_x_notch[nrk, j - 1];
                prev_y_notch[nrk, j] = prev_y_notch[nrk, j - 1];
                prev_x_standard[nrk, j] = prev_x_standard[nrk, j - 1];
                prev_y_standard[nrk, j] = prev_y_standard[nrk, j - 1];
            }
            prev_x_notch[nrk, 0] = data; // ingreso del nuevo filtro

            double result = 0;
            for (int j = 0; j < 5; j++)  // ciclo para aplicar los filtros y luego se elimina 
            {
                result += b2[j] * prev_x_notch[nrk, j];
                if (j > 0)
                {
                    result -= a2[j] * prev_y_notch[nrk, j];
                }
            }
            prev_y_notch[nrk, 0] = result;  // se gurdan los valores aplicacndo los filtros notch en y y el estandar en x
            prev_x_standard[nrk, 0] = result;
            result = 0;
            for (int j = 0; j < 5; j++) // se gurdan los valores aplicacndo los filtros notch en x y el estandar en y
            {
                result += b[j] * prev_x_standard[nrk, j];
                if (j > 0)
                {
                    result -= a[j] * prev_y_standard[nrk, j];
                }
            }
            prev_y_standard[nrk, 0] = result;
            return result;
        }

        //Función para elegir los canales 
        public static double[] SetChannels(double [] Data, int [] set, Boolean p)
        { // la variable P dicta si se desa o no anular algun canal
        // vector set contiene ceros en las casillas correspondientes a los canales que se desean anular
        //Data es el vector de entrada de lectura
          if(p == true) { 
                for (int i = 1; i < 9; i++)
                {
                    if(set[i] == 0)
                    {
                        contch--;
                        if(contch <= 1)
                        {
                            contch = 1;
                        }
                        Data[i] = 0;
                    }
                    else
                    {
                        if(contch == 8)
                        {

                        }
                        else
                        {
                            contch++;
                        }
                    }
                }
            }
            return Data;
        }

        //Funciones para aplicar filtros de frencuencia

        //1. SetAll: Limita las frecuencai de entrada entre 1 a 50 Hz.
        public static double[] SetAll(double [] Data)
        {
            b = new double[5] { 0.2001387256580675, 0, -0.4002774513161350, 0, 0.2001387256580675 };
            a = new double[5] { 1, -2.355934631131582, 1.941257088655214, -0.7847063755334187, 0.1999076052968340 };
            standard = 1; 
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }

        //2. SetAlpha: Limita las frecuencia de entrada entre 7 a 13 Hz.
        public static double[] SetAlpha(double[] Data)
        {
            b = new double[5] { 0.005129268366104263, 0, -0.01025853673220853, 0, 0.005129268366104263 };
            a = new double[5] { 1, -3.678895469764040, 5.179700413522124, -3.305801890016702, 0.8079495914209149 };
            standard = 2;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //3. SetBeta: Limita las frecuencia de entrada entre 15 a 50 Hz.
        public static double[] SetBeta(double[] Data)
        {
            b = new double[5] { 0.1173510367246093, 0, -0.2347020734492186, 0, 0.1173510367246093 };
            a = new double[5] { 1, -2.137430180172061, 2.038578008108517, -1.070144399200925, 0.2946365275879138 };
            standard = 3;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //4. SetGandD: Limita las frecuencia de entrada entre 5 a 50 Hz.
        public static double[] SetGandD(double[] Data)
        {
            b = new double[5] { 0.1173510367246093, 0, -0.2347020734492186, 0, 0.1173510367246093 };
            a = new double[5] { 1, -2.137430180172061, 2.038578008108517, -1.070144399200925, 0.2946365275879138 };
            standard = 4;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //5. SetNone: Limita las frecuencia de entrada entre 1 a 60 Hz.
        public static double[] SetNone(double[] Data)
        {
            b = new double[5] { 1, 1, 1, 1, 1 };
            a = new double[5] { 1, 1, 1, 1, 1 };
            standard = 0;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //Funciones para aplicar filtros Notch
        //1. SetNotch50: aplica un filtro notch a 50 Hz.
        public static double[] SetNotch50(double[] Data)
        {
            b2 = new double[5] { 0.96508099, -1.19328255, 2.29902305, -1.19328255, 0.96508099 };
            a2 = new double[5] { 1, -1.21449347931898, 2.29780334191380, -1.17207162934772, 0.931381682126902 };
            notch = 1;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //2. SetNotch60: aplica un filtro notch a 60 Hz.
        public static double[] SetNotch60(double[] Data)
        {
            b2 = new double[5] { 0.9650809863447347, -0.2424683201757643, 1.945391494128786, -0.2424683201757643, 0.9650809863447347 };
            a2 = new double[5] { 1, -0.2467782611297853, 1.944171784691352, -0.2381583792217435, 0.9313816821269039 };
            notch = 2;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //3. SetNotch60: quita el filtro tipo notch.
        public static double[] SetZNotch(double[] Data)
        {
            b2 = new double[5] { 1, 1, 1, 1, 1 };
            a2 = new double[5] { 1, 1, 1, 1, 1 };
            notch = 0;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = filterIIR(a2, b2, a, b, Data[i + 1], i);
            }

            return Data;
        }
        //Filtros para límitar la amplitud del voltaje 

        //Funciones para otras cosas

        //Función para almacenar el valor leido de un canal en un array para luego poder obtener las 256 muestras
        public static double GetDataCH(Boolean flag, double[] Data, double[] Data2, int cont)
        {
            if (flag == false)
            {
                return Data[cont];
            }
            else
            {
                return 0;
            }

        }
        
        //función para incrementar el contador de la cantidad de muestras, dependiendo del estado de la bandera
        public static int GetCont(int cont, Boolean flag)
        {
            if (flag == false)
            {

                cont++;
            }

            if (cont == 256)
            {
                cont = 0;
            }
            return cont;
        }

        // Función para verificar el estado de la bandera, dependiendo del estado del contador
        public static Boolean CheckFlag(int cont, Boolean flag)
        {
            if (cont == 0)
            {
                flag = true;
            }
            return flag;
        }
        //Funciones para realizar la FFT
        //Función para llenar los arrays complejos
        public static Complex[] GenerateComplex(Boolean flag, double[] Data, Complex[] samples)
        {

            if (flag == true)
            {

                for (int i = 0; i < 256; i++)
                {
                    samples[i] = new Complex(Data[i], 0);
                }
            }
            return samples;
        }
        //Función que realiza la FFT
        public static Complex[] FFT(Complex[] samples)
        {
            Fourier.Forward(samples, FourierOptions.NoScaling);
            return samples;
        }
        //Función para obtener la maginitud 
        public static double GetMagnitude(Complex[] samples, int i)
        {
            double mag = (2.0 / 256) * (Math.Abs(Math.Sqrt(Math.Pow(samples[i].Real, 2) + Math.Pow(samples[i].Imaginary, 2))));

            return mag;

        }
        //Función para obtener la cuenta de un tipo de onda de interes
        public static int GetSignalCount(int count, int i, String type)
        {
            if (type == "Alpha" || type == "alpha" || type == "1")
            {
                if ((i) >= alpha_low && (i) <= alpha_up)
                {
                    count++;
                    
                }
                if (count > (alpha_up-alpha_low))
                {
                    count = (alpha_up - alpha_low);
                }

            }
            if (type == "Beta" || type == "beta" || type == "2")
            {
                if ((i) >= beta_low && (i) <= beta_up)
                {
                    count++;
                }

                if (count > (beta_up-beta_low))
                {
                    count = (beta_up - beta_low);
                }
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                if ((i) >= rms_low && (i) <= rms_up)
                {
                    count++;
                }

                if (count > (rms_up-rms_low))
                {
                    count = (rms_up - rms_low);
                }
            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                if ((i) >= mbeta_low && (i) <= mbeta_up)
                {
                    count++;
                }

                if (count > (mbeta_up-mbeta_low))
                {
                    count = (mbeta_up - mbeta_low);
                }
            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                if ((i) >= hbeta_low && (i) <= hbeta_up)
                {
                    count++;
                }

                if (count > (hbeta_up - hbeta_low))
                {
                    count = (hbeta_up - hbeta_low);
                }
            }
            if (type == "Theta" || type == "theta" || type == "3")
            {
                if ((i) >= theta_low && (i) <= theta_up)
                {
                    count++;
                }
                if (count > (theta_up - theta_low))
                {
                    count = (theta_up - theta_low);
                }
            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {
                if ((i) >= delta_low && (i) <= delta_up)
                {
                    count++;
                }
                if (count > (delta_up - delta_low))
                {
                    count = (delta_up - delta_low);
                }

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                if ((i) >= gamma_low && (i) <= gamma_up)
                {
                    count++;
                }
                if (count > (gamma_up - gamma_low))
                {
                    count = (gamma_up - gamma_low);
                }

            }
            return count;
        }
        //Función para obtener la cuenta de un tipo de onda de interes
        public static double GetSignalAverage(double avg, double mag, double mag2, int i, String type)
        {
            if (type == "Alpha" || type == "alpha" || type == "1")
            {
                if ((i) >= alpha_low && (i) <= alpha_up)
                {
                    avg += mag + mag2;
                }
            }
            if (type == "Beta" || type == "beta" || type == "2")
            {
                if ((i) >= beta_low && (i) <= beta_up)
                {
                    avg += mag + mag2;
                }
            }
            if (type == "Theta" || type == "theta" || type == "3")
            {
                if ((i) >= theta_low && (i) <= theta_up)
                {
                    avg += mag + mag2;
                }
            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {
                if ((i) >= delta_low && (i) <= delta_up)
                {
                    avg += mag + mag2;
                }

            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                if ((i) >= rms_low && (i) <= rms_up)
                {
                    avg += mag + mag2;
                }

            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                if ((i) >= mbeta_low && (i) <= mbeta_up)
                {
                    avg += mag + mag2;
                }

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                if ((i) >= hbeta_low && (i) <= hbeta_up)
                {
                    avg += mag + mag2;
                }

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                if ((i) >= gamma_low && (i) <= gamma_up)
                {
                    avg += mag + mag2;
                }

            }
            return avg;
        }
        //Función para obtener la cuenta de un tipo de onda de interes
        public static double GetSignalAverage2(double avg, int count, String type)
        {
            if (type == "Alpha" || type == "alpha" || type == "1")
            {
               
                avg  = avg/(1.0*count*contch);
                
            }
            if (type == "Beta" || type == "beta" || type == "2")
            {

                avg = avg / (1.0 * count * contch);

            }
            if (type == "Theta" || type == "theta" || type == "3")
            {

                avg = avg / (1.0 * count * contch);

            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {

                avg = avg / (1.0 * count * contch);
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                avg = avg / (1.0 * count * contch);
             
            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                avg = avg / (1.0 * count * contch);

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                avg = avg / (1.0 * count * contch);

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                avg = avg / (1.0 * count * contch);

            }
            return avg;
        }

        //Función para obtener el límite superior de una onda
        public static int ReadUpLimit(String type)
        {
            int i = 0;
            if (type == "Alpha" || type == "alpha" || type == "1")
            {

                i = alpha_up;

            }
            if (type == "Beta" || type == "beta" || type == "2")
            {

                i = beta_up;

            }
            if (type == "Theta" || type == "theta" || type == "3")
            {

                i = theta_up;

            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {

                i = delta_up;
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                i = rms_up;

            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                i = mbeta_up;

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                i = hbeta_up;

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                i = gamma_up;

            }
            return i;
        }

        //Función para cambiar el límite superior de una onda
        public static void WriteLowLimit(String type, int i)
        {
            if (type == "Alpha" || type == "alpha" || type == "1")
            {

                alpha_low = i;

            }
            if (type == "Beta" || type == "beta" || type == "2")
            {

                beta_low = i;

            }
            if (type == "Theta" || type == "theta" || type == "3")
            {

                theta_low = i;

            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {

                delta_low = i;
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                rms_low = i;

            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                mbeta_low = i;

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                hbeta_low = i;

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                gamma_low = i;

            }
        }
        //Función para cambiar el límite superior de una onda
        public static void WriteUpLimit(String type, int i)
        {
            if (type == "Alpha" || type == "alpha" || type == "1")
            {

                alpha_up = i;

            }
            if (type == "Beta" || type == "beta" || type == "2")
            {

                beta_up = i;

            }
            if (type == "Theta" || type == "theta" || type == "3")
            {

                theta_up = i;

            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {

                delta_up = i;
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                rms_up = i;

            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                mbeta_up = i;

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                hbeta_up = i;

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                gamma_up = i;

            }

        }

        //Función para obtener el límite superior de una onda
        public static int ReadLowLimit(String type)
        {
            int i = 0;
            if (type == "Alpha" || type == "alpha" || type == "1")
            {

                i = alpha_low;

            }
            if (type == "Beta" || type == "beta" || type == "2")
            {

                i = beta_low;

            }
            if (type == "Theta" || type == "theta" || type == "3")
            {

                i = theta_low;

            }
            if (type == "Delta" || type == "Delta" || type == "4")
            {

                i = delta_low;
            }
            if (type == "RMS" || type == "rms" || type == "5")
            {
                i = rms_low;

            }
            if (type == "MBeta" || type == "mbeta" || type == "6")
            {
                i = mbeta_low;

            }
            if (type == "HBeta" || type == "hbeta" || type == "7")
            {
                i = hbeta_low;

            }
            if (type == "Gamma" || type == "gamma" || type == "8")
            {
                i = gamma_low;

            }
            return i;
        }
        // Función para obtener la escala de las barras de progreso
        public static int GetScale(double avg, double top)
        {
            int h = (int) (avg * (100 / top));
            if (h > 100)
            {
                h = 100;
            }
            if (h < 0)
            {
                h = 0;
            }
            return h;
        }

        //Funciones para verificar los límites de los cuatro tipos de señales 

        public static Boolean CheckStatus(double avg, double upper, double thresh, string type, Boolean Status)
        {
            
            if (type == "both" || type == "Both")
            {
                if(avg < upper && avg > thresh)
                {
                     Status = true;
                }
                else
                {
                    Status = false;
                }
            }

            if (type == "upper" || type == "Upper")
            {
                if (avg < upper)
                {
                    Status = true;
                }
                else
                {
                    Status = false;
                }
            }

            if (type == "Thresh" || type == "thresh")
            {
                if (avg < thresh)
                {
                    Status = true;
                }
                else
                {
                    Status = false;
                }

            }
            if (type == "adove" || type == "Adove")
            {
                if (avg < thresh)
                {
                    Status = true;
                }
                else
                {
                    Status = false;
                }

            }
            return Status;
        }

        // Verificación del límite inferior 

        //función para escribir los datos en un archivo de texto
        public static void writeToFile(double[] DataLynx, Boolean HSW, StreamWriter sw) 
        {
            double mnoz = (4.5 / 24 / (Math.Pow(2, 23) - 1)) * (Math.Pow(10, 6));

            for (int i = 0; i < 8; i++)
            {
                DataLynx[i + 1] = DataLynx[i + 1] * mnoz;
            }
            if (HSW)
            {
                sw.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11}", DataLynx[0], DataLynx[1], DataLynx[2], DataLynx[3], DataLynx[4], DataLynx[5], DataLynx[6], DataLynx[7], DataLynx[8], DataLynx[9], DataLynx[10], DataLynx[11]);
            }
        }
    }
}
