﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
// Utilizada para generar las señales sinusoidales. 
using MathNet.Numerics;
// Usada para realizar la FFT
using MathNet.Numerics.IntegralTransforms;
// para los números complejos
using System.Numerics;
// para generar las graficas
using System.Windows.Forms.DataVisualization.Charting;

namespace OpenBCI_GUI
{
    public partial class Form1 : Form
    {
        StreamWriter sw; // Se usa para escribir los caracteres de una secuencia en una forma determianda
        bool HSW = false; // presencia de steamwrite
        Complex[] samples = new Complex[256];
        Complex[] samples2 = new Complex[256];
        double[] Data2 = new double[256];
        double[] Data3 = new double[256];
        Boolean p = false;
        int cont = 0;
        int alpha_count = 0;
        int beta_count = 0;
        int x = 0, y = 0, z = 0;
        Boolean isFocused;
        int h, h2;
        public Form1()
        {
            InitializeComponent();

            foreach (string s in SerialPort.GetPortNames()) // se agregan los posibles puestos COM a la lista
            {
                comboBox1.Items.Add(s); 
            }
            comboBox1.SelectedItem = "COM16";

            textBox2.Text = Application.StartupPath;
            textBox3.Text = "test.txt";

            radioButton4.Checked = true;
            radioButton5.Checked = true;
            radioButton8.Checked = true;

            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;

            checkBox1.Checked = true;
            checkBox2.Checked = true;
            checkBox3.Checked = true;
            checkBox4.Checked = true;
            checkBox5.Checked = true;
            checkBox6.Checked = true;
            checkBox7.Checked = true;
            checkBox8.Checked = true;
        }
        
        struct DataSerialPort
        {
            public byte[] Var; // array de bytes, que es parate de la estructura del DataSerialPort
        };

        Queue<DataSerialPort> driver = new Queue<DataSerialPort>(); // inicialización del driver de tipo DSP


        void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e) //función de 
        {
            DataSerialPort received_Data; // DSP para las entradas
            byte[] buffer = new byte[serialPort1.BytesToRead]; //array de bytes con los datos de entrada
            serialPort1.Read(buffer, 0, buffer.Length); //lectura del puerto
            received_Data.Var = buffer; //Se almacena el buffer en la variable DSP
            driver.Enqueue(received_Data); //se agregan la entrada recibida al driver que contiene todos los datos
        }

        private void button1_Click(object sender, EventArgs e) // OpenPort
        {
            serialPort1.PortName = comboBox1.Text; // selección del puerto
            serialPort1.BaudRate = 115200; // se establece el Baudrate
            try
            {
                serialPort1.Open(); // se intenta abrir el puerto para la conexión
                button1.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = true;
            }
            catch
            {
                MessageBox.Show("No se puede abrir el puerto " + comboBox1.Text.ToString());
            }
            serialPort1.DataReceived += serialPort1_DataReceived;  // se agrega la data de entrada a la que ya se tiene
        }

        private void button2_Click(object sender, EventArgs e) //close port
        {
            turnOFF_SW();  // se corta la transmición de datos y se cierra el puerto
            turnOFF_transmision();
            serialPort1.Close();
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e) //Start Stream
        {
            char[] buff = new char[1]; //array de chars
            buff[0] = 'b'; // es el caracter que se envia para inciar la comuniación (protocolo de OPENBCI)
            try
            {
                serialPort1.Write(buff, 0, 1);
            }
            catch
            {
                MessageBox.Show("No se puede ejecutar");
            }
            button3.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e) // Stop Stream
        {
            turnOFF_SW();
            turnOFF_transmision();
            button4.Enabled = false;
            button3.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e) //Write to File
        {
            try
            {
                Directory.CreateDirectory(textBox2.Text);
                sw = new StreamWriter(Path.Combine(textBox2.Text, textBox3.Text));
                HSW = true;
            }
            catch
            {
                MessageBox.Show("El directorio no se puede crear directamente en la partición principal.");
            }
            button5.Enabled = false;
            button6.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e) // Stop Write
        {
            turnOFF_SW();
            button5.Enabled = true;
            button6.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e) //timer Tick
        {
            double[] DataLynx; //array de tipo double que contiene el bosquejo de los datos
            while (driver.Count > 0) //while con la condición de que la cantidad de elementos incluidos en Queue sea mayor que 0
            {
                DataSerialPort data = driver.Dequeue(); // se quita y devuelve el objeto al comienzo del Queue
                for (int g = 0; g < data.Var.Length; g++)  // ciclo para interpretar el byte de entrada
                {
                    DataLynx = Convert.interpretBinaryStream(data.Var[g]); //se utiliza la función del documento convert
                    //DataLynx es un array de 8 bytes que contienen la información de los canales
                    if (DataLynx != null) //con de que el valor de DataLynx sea correcta, se procede a la segunda parte del proceso
                    {
                        //DataLynx = ValueOrZero(DataLynx); // se utiliza la función ValueOrZero que se describe abajo
                        int[] set = new int[] {4,1,1,0,0,0,0,0,0};
                        Boolean p = true;
                        DataLynx = Functions.SetChannels(DataLynx, set, p);

                        writeToFile(DataLynx); //funciones descritas  abajo
                        drawPlot(DataLynx);
                    }
                }
            }

        }

        private void writeToFile(double[] DataLynx) //función para escribir los datos en un archivo de texto
        {
            double mnoz = (4.5 / 24 / (Math.Pow(2, 23) - 1)) * (Math.Pow(10, 6));

            for (int i = 0; i < 8; i++)
            {
                DataLynx[i + 1] = DataLynx[i + 1] * mnoz;
            }
            if (HSW)
            {
                sw.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11}", DataLynx[0], DataLynx[1], DataLynx[2], DataLynx[3], DataLynx[4], DataLynx[5], DataLynx[6], DataLynx[7], DataLynx[8], DataLynx[9], DataLynx[10], DataLynx[11]);
            }
        }

        private void drawPlot(double[] Data) //función para graficar los resultados
        {
            Data = filtering(Data);

            int SpecSize = 250 / 2 + 1;
            // output values
            double alpha_avg = 0;
            double beta_avg = 0;
           

            // alpha, beta threshold default values
            double alpha_thresh = trackBar1.Value/10.0;
            double beta_thresh = trackBar2.Value/10.0;

            

            double alpha_upper = 2;
            double beta_upper = 2;

            // determinar cuantos Hz representa cada una de las muestras
            float hzPerSample = 250 / 256;
            double FFT_freq_Hz;
            double FFT_value_uV;
            double FFT_value_uV2;

            if (p == false)
            {
                Data2[cont] = Data[1];
                Data3[cont] = Data[2];
                cont++;
                if(cont == 256)
                {
                    cont = 0;
                    p = true;
                }
            }
            
            if (p == true) {

                for (int i = 0; i < 256; i++)
                {
                    samples[i] = new Complex(Data2[i], 0);
                    samples2[i] = new Complex(Data3[i], 0);

                }

                chart10.Series["Freq"].Points.Clear();
                chart10.Series["Fase"].Points.Clear();

                chart11.Series["Freq"].Points.Clear();
                chart11.Series["Fase"].Points.Clear();
                // "Forward" Fourier convierte tiempo en freq
                Fourier.Forward(samples, FourierOptions.NoScaling);
                Fourier.Forward(samples2, FourierOptions.NoScaling);

                //grafica el espectro de frecuencia
                // solo se necesita la mitad de las muestras
                for (int i = 1; i < samples.Length/2; i++)
                {
                    chart10.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart10.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart10.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart10.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart10.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart11.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart11.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart11.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart11.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart11.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    // Se obitnee la magnitud de cada una de las muestras de la FFT:
                    //  = abs[sqrt(real^2 + imaginario^2)]
                    double mag = (2.0 / 256) * (Math.Abs(Math.Sqrt(Math.Pow(samples[i].Real, 2) + Math.Pow(samples[i].Imaginary, 2))));
                    double mag2 = (2.0 / 256) * (Math.Abs(Math.Sqrt(Math.Pow(samples2[i].Real, 2) + Math.Pow(samples2[i].Imaginary, 2))));
            
                  

                    if ( (i ) >= 7 && (i ) <= 13)
                    {
                        alpha_count++;
                        x++;
                        alpha_avg += mag + mag2;
                        // radioButton14.Text = x.ToString();
            
                    }
                    if ((i) >= 14 && (i) <= 30)
                    {
                        beta_count++;
                        y++;
                        //radioButton15.Text = y.ToString();
                        beta_avg += mag + mag2;
                    }
                    
                    //                   FFT_freq_Hz =  1.0*hzPerSample*i;
                    //                   FFT_value_uV = mag;
                    //                   FFT_value_uV2 = mag2;
                    //                  //radioButton18.Text = i.ToString();
                    //                  if (FFT_freq_Hz >= 7 && FFT_freq_Hz <= 14)
                    //                   { //FFT bins in alpha range
                    //                  alpha_avg += FFT_value_uV;
                    //                       alpha_avg += FFT_value_uV2;
                    //                  alpha_count++;
                    //                  }
                    //                 else if (FFT_freq_Hz > 14 && FFT_freq_Hz <= 20)
                    //                {  //FFT bins in beta range
                    //                beta_avg += FFT_value_uV;
                    //                beta_avg += FFT_value_uV2;
                    //                beta_count++;
                    //             }

                    alpha_avg = alpha_avg / 7.0;  // average uV per bin
                                                          //alpha_avg = alpha_avg / (cyton.getSampleRate()/Nfft);  // average uV per delta freq
                    beta_avg = beta_avg / 16.0;  // average uV per bin
                                                 //beta_avg = beta_avg / (cyton.getSampleRate()/Nfft);  // average uV per delta freq


                    //var result = Math.Round(alpha_avg, 2, MidpointRounding.AwayFromZero);
                    //var str = String.Format("{0:0.00}", result);



                    //double beta_avg2 = Math.Round(beta_avg, 2);

                    label5.Text = alpha_avg.ToString();
                    label6.Text = beta_avg.ToString();

                    label3.Text = alpha_thresh.ToString();
                    label4.Text = beta_thresh.ToString();

                    h = (int)(alpha_avg * 50*Math.Pow(10,95));
                    h2 = (int)(beta_avg * 50 * Math.Pow(10, 116));

                    label8.Text = h2.ToString();
                    label7.Text = h.ToString();
                    
                    //label7.Text = h2.ToString();

                    if (h > 100)
                    {
                        h = 100;
                    }
                    if  (h2 >100)
                    {
                        h2 = 100;
                    }
                    if (h < 0)
                    {
                        h = 0;
                    }
                    if (h2 < 0)
                    {
                        h2 = 0;
                    }

                    progressBar1.Value = h;
                    progressBar2.Value = h2;

                   // progressBar1.Update();
                    //progressBar2.Update();

                    //progressBar2.Value = h2;
                    //current time = int(float(currentTableRowIndex)/cyton.getSampleRate());
                    // version 1

                    if (alpha_avg > alpha_thresh && alpha_avg < alpha_upper && beta_avg < beta_thresh)
                    {
                        isFocused = true;
                        timer2.Enabled = true;
                    }
                    else
                    {
                       // isFocused = false;
                    }

                    if (isFocused == true)
                    {
                        button7.Text = "Concentrado";
                        button7.BackColor = Color.Red;
                    }
                    else
                    {
                        button7.Text = "No Concentrado";
                        button7.BackColor = Color.Blue;
                    }
                    chart10.Series["Freq"].Points.AddXY(hzPerSample * i, mag);
                    chart11.Series["Freq"].Points.AddXY(hzPerSample * i, mag2);
                    p = false;
                }
            }
            //Data = Functions.SetAlpha(Data);

                chart1.Series[0].Points.Add(Data[0]);
                chart2.Series[0].Points.Add(Data[1]);
                chart3.Series[0].Points.Add(Data[2]);
                chart4.Series[0].Points.Add(Data[3]);
                chart5.Series[0].Points.Add(Data[4]);
                chart6.Series[0].Points.Add(Data[5]);
                chart7.Series[0].Points.Add(Data[6]);
                chart8.Series[0].Points.Add(Data[7]);
                chart9.Series[0].Points.Add(Data[8]);

                while (chart1.Series[0].Points.Count > 1250)
                {
                    chart1.Series[0].Points.SuspendUpdates();
                    chart1.Series[0].Points.Remove(chart1.Series[0].Points.First());
                    chart1.Series[0].Points.ResumeUpdates();

                    chart2.Series[0].Points.SuspendUpdates();
                    chart2.Series[0].Points.Remove(chart2.Series[0].Points.First());
                    chart2.Series[0].Points.ResumeUpdates();

                    chart3.Series[0].Points.SuspendUpdates();
                    chart3.Series[0].Points.Remove(chart3.Series[0].Points.First());
                    chart3.Series[0].Points.ResumeUpdates();

                    chart4.Series[0].Points.SuspendUpdates();
                    chart4.Series[0].Points.Remove(chart4.Series[0].Points.First());
                    chart4.Series[0].Points.ResumeUpdates();

                    chart5.Series[0].Points.SuspendUpdates();
                    chart5.Series[0].Points.Remove(chart5.Series[0].Points.First());
                    chart5.Series[0].Points.ResumeUpdates();

                    chart6.Series[0].Points.SuspendUpdates();
                    chart6.Series[0].Points.Remove(chart6.Series[0].Points.First());
                    chart6.Series[0].Points.ResumeUpdates();

                    chart7.Series[0].Points.SuspendUpdates();
                    chart7.Series[0].Points.Remove(chart7.Series[0].Points.First());
                    chart7.Series[0].Points.ResumeUpdates();

                    chart8.Series[0].Points.SuspendUpdates();
                    chart8.Series[0].Points.Remove(chart8.Series[0].Points.First());
                    chart8.Series[0].Points.ResumeUpdates();

                    chart9.Series[0].Points.SuspendUpdates();
                    chart9.Series[0].Points.Remove(chart9.Series[0].Points.First());
                    chart9.Series[0].Points.ResumeUpdates();
                }
        }

        private double[] ValueOrZero(double[] Data) //basicamente se verifican cuales son los canales encendidos 
        {
            if (!checkBox1.Checked)
            {
                Data[1] = 0;
            }
            if (!checkBox2.Checked)
            {
                Data[2] = 0;
            }
            if (!checkBox3.Checked)
            {
                Data[3] = 0;
            }
            if (!checkBox4.Checked)
            {
                Data[4] = 0;
            }
            if (!checkBox5.Checked)
            {
                Data[5] = 0;
            }
            if (!checkBox6.Checked)
            {
                Data[6] = 0;
            }
            if (!checkBox7.Checked)
            {
                Data[7] = 0;
            }
            if (!checkBox8.Checked)
            {
                Data[8] = 0;
            }
            return Data;
        }

        private double[] filtering(double[] Data) //función para agregar los filtros, el proceso de esta se detalla en el archivo filters
        {
            int standard = 0;
            int notch = 0;

            if (radioButton5.Checked)
            {
                notch = 0;
                Data = Functions.SetZNotch(Data);
            }
            else if (radioButton6.Checked)
            {
                notch = 1;
                Data = Functions.SetNotch50(Data);
            }
            else if (radioButton7.Checked)
            {
                notch = 2;
                Data = Functions.SetNotch60(Data);
            }
            if (radioButton8.Checked)
            {
                standard = 0;
                Data = Functions.SetNone(Data);
            }
            if (radioButton9.Checked)
            {
                standard = 1;
                Data = Functions.SetAll(Data);
            }
            if (radioButton10.Checked)
            {
                standard = 2;
                Data = Functions.SetAlpha(Data);
            }
            if (radioButton11.Checked)
            {
                standard = 3;
                Data = Functions.SetBeta(Data);
            }
            if (radioButton12.Checked)
            {
                standard = 4;
                Data = Functions.SetGandD(Data);
            }

            //for (int i = 0; i < 8; i++)
            //{
            //    Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            //}

            return Data;
        }

        private void turnOFF_SW()  //función para cerrar el puerto
        {
            if (HSW)
            {
                HSW = false;
                sw.Close();
            }
        }
        private void turnOFF_transmision() //función para parar la transmisión
        {
            char[] buff = new char[1];
            buff[0] = 's';
            serialPort1.Write(buff, 0, 1);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //-1V 1V
            chart2.ChartAreas[0].AxisY.Maximum = 1000000;
            chart2.ChartAreas[0].AxisY.Minimum = -1000000;

            chart3.ChartAreas[0].AxisY.Maximum = 1000000;
            chart3.ChartAreas[0].AxisY.Minimum = -1000000;

            chart4.ChartAreas[0].AxisY.Maximum = 1000000;
            chart4.ChartAreas[0].AxisY.Minimum = -1000000;

            chart5.ChartAreas[0].AxisY.Maximum = 1000000;
            chart5.ChartAreas[0].AxisY.Minimum = -1000000;

            chart6.ChartAreas[0].AxisY.Maximum = 1000000;
            chart6.ChartAreas[0].AxisY.Minimum = -1000000;

            chart7.ChartAreas[0].AxisY.Maximum = 1000000;
            chart7.ChartAreas[0].AxisY.Minimum = -1000000;

            chart8.ChartAreas[0].AxisY.Maximum = 1000000;
            chart8.ChartAreas[0].AxisY.Minimum = -1000000;

            chart9.ChartAreas[0].AxisY.Maximum = 1000000;
            chart9.ChartAreas[0].AxisY.Minimum = -1000000;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //-100mV 100mV
            chart2.ChartAreas[0].AxisY.Maximum = 100000;
            chart2.ChartAreas[0].AxisY.Minimum = -100000;

            chart3.ChartAreas[0].AxisY.Maximum = 100000;
            chart3.ChartAreas[0].AxisY.Minimum = -100000;

            chart4.ChartAreas[0].AxisY.Maximum = 100000;
            chart4.ChartAreas[0].AxisY.Minimum = -100000;

            chart5.ChartAreas[0].AxisY.Maximum = 100000;
            chart5.ChartAreas[0].AxisY.Minimum = -100000;

            chart6.ChartAreas[0].AxisY.Maximum = 100000;
            chart6.ChartAreas[0].AxisY.Minimum = -100000;

            chart7.ChartAreas[0].AxisY.Maximum = 100000;
            chart7.ChartAreas[0].AxisY.Minimum = -100000;

            chart8.ChartAreas[0].AxisY.Maximum = 100000;
            chart8.ChartAreas[0].AxisY.Minimum = -100000;

            chart9.ChartAreas[0].AxisY.Maximum = 100000;
            chart9.ChartAreas[0].AxisY.Minimum = -100000;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //-10mv 10mv
            chart2.ChartAreas[0].AxisY.Maximum = 10000;
            chart2.ChartAreas[0].AxisY.Minimum = -10000;

            chart3.ChartAreas[0].AxisY.Maximum = 10000;
            chart3.ChartAreas[0].AxisY.Minimum = -10000;

            chart4.ChartAreas[0].AxisY.Maximum = 10000;
            chart4.ChartAreas[0].AxisY.Minimum = -10000;

            chart5.ChartAreas[0].AxisY.Maximum = 10000;
            chart5.ChartAreas[0].AxisY.Minimum = -10000;

            chart6.ChartAreas[0].AxisY.Maximum = 10000;
            chart6.ChartAreas[0].AxisY.Minimum = -10000;

            chart7.ChartAreas[0].AxisY.Maximum = 10000;
            chart7.ChartAreas[0].AxisY.Minimum = -10000;

            chart8.ChartAreas[0].AxisY.Maximum = 10000;
            chart8.ChartAreas[0].AxisY.Minimum = -10000;

            chart9.ChartAreas[0].AxisY.Maximum = 10000;
            chart9.ChartAreas[0].AxisY.Minimum = -10000;
        }

   

        private void timer3_Tick(object sender, EventArgs e)
        {
           
        }

        private void timer2_Tick(object sender, EventArgs e)
        {

            isFocused = false;
            timer2.Enabled = false;
            
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //-1mV
            chart2.ChartAreas[0].AxisY.Maximum = 1000;
            chart2.ChartAreas[0].AxisY.Minimum = -1000;

            chart3.ChartAreas[0].AxisY.Maximum = 1000;
            chart3.ChartAreas[0].AxisY.Minimum = -1000;

            chart4.ChartAreas[0].AxisY.Maximum = 1000;
            chart4.ChartAreas[0].AxisY.Minimum = -1000;

            chart5.ChartAreas[0].AxisY.Maximum = 1000;
            chart5.ChartAreas[0].AxisY.Minimum = -1000;

            chart6.ChartAreas[0].AxisY.Maximum = 1000;
            chart6.ChartAreas[0].AxisY.Minimum = -1000;

            chart7.ChartAreas[0].AxisY.Maximum = 1000;
            chart7.ChartAreas[0].AxisY.Minimum = -1000;

            chart8.ChartAreas[0].AxisY.Maximum = 1000;
            chart8.ChartAreas[0].AxisY.Minimum = -1000;

            chart9.ChartAreas[0].AxisY.Maximum = 1000;
            chart9.ChartAreas[0].AxisY.Minimum = -1000;
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            //-100uV
            chart2.ChartAreas[0].AxisY.Maximum = 100;
            chart2.ChartAreas[0].AxisY.Minimum = -100;

            chart3.ChartAreas[0].AxisY.Maximum = 100;
            chart3.ChartAreas[0].AxisY.Minimum = -100;

            chart4.ChartAreas[0].AxisY.Maximum = 100;
            chart4.ChartAreas[0].AxisY.Minimum = -100;

            chart5.ChartAreas[0].AxisY.Maximum = 100;
            chart5.ChartAreas[0].AxisY.Minimum = -100;

            chart6.ChartAreas[0].AxisY.Maximum = 100;
            chart6.ChartAreas[0].AxisY.Minimum = -100;

            chart7.ChartAreas[0].AxisY.Maximum = 100;
            chart7.ChartAreas[0].AxisY.Minimum = -100;

            chart8.ChartAreas[0].AxisY.Maximum = 100;
            chart8.ChartAreas[0].AxisY.Minimum = -100;

            chart9.ChartAreas[0].AxisY.Maximum = 100;
            chart9.ChartAreas[0].AxisY.Minimum = -100;
        }
        
    }
}
