﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBCI_GUI
{
    class Functions
    {
        public static int notch = 0; 
        public static int standard = 0;
        public static double[] b ; //arrays necesarios para aplicar los filtros, 
        public static double[] a; // a y b son para filtros pasa banda y a2 y b2 para filtros notch
        public static double[] b2;
        public static double[] a2;
        //Función para elegir los canales 
        public static double[] SetChannels(double [] Data, int [] set, Boolean p)
        { // la variable P dicta si se desa o no anular algun canal
        // vector set contiene ceros en las casillas correspondientes a los canales que se desean anular
        //Data es el vector de entrada de lectura
          if(p == true) { 
                for (int i = 1; i < 9; i++)
                {
                    if(set[i] == 0)
                    {
                        Data[i] = 0;
                    }
                }
            }
            return Data;
        }

        //Funciones para aplicar filtros de frencuencia

        //1. SetAll: Limita las frecuencai de entrada entre 1 a 50 Hz.
        public static double[] SetAll(double [] Data)
        {
            b = new double[5] { 0.2001387256580675, 0, -0.4002774513161350, 0, 0.2001387256580675 };
            a = new double[5] { 1, -2.355934631131582, 1.941257088655214, -0.7847063755334187, 0.1999076052968340 };
            standard = 1; 
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }

        //2. SetAlpha: Limita las frecuencia de entrada entre 7 a 13 Hz.
        public static double[] SetAlpha(double[] Data)
        {
            b = new double[5] { 0.005129268366104263, 0, -0.01025853673220853, 0, 0.005129268366104263 };
            a = new double[5] { 1, -3.678895469764040, 5.179700413522124, -3.305801890016702, 0.8079495914209149 };
            standard = 2;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //3. SetBeta: Limita las frecuencia de entrada entre 15 a 50 Hz.
        public static double[] SetBeta(double[] Data)
        {
            b = new double[5] { 0.1173510367246093, 0, -0.2347020734492186, 0, 0.1173510367246093 };
            a = new double[5] { 1, -2.137430180172061, 2.038578008108517, -1.070144399200925, 0.2946365275879138 };
            standard = 3;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //4. SetGandD: Limita las frecuencia de entrada entre 5 a 50 Hz.
        public static double[] SetGandD(double[] Data)
        {
            b = new double[5] { 0.1173510367246093, 0, -0.2347020734492186, 0, 0.1173510367246093 };
            a = new double[5] { 1, -2.137430180172061, 2.038578008108517, -1.070144399200925, 0.2946365275879138 };
            standard = 4;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //5. SetNone: Limita las frecuencia de entrada entre 1 a 60 Hz.
        public static double[] SetNone(double[] Data)
        {
            b = new double[5] { 1, 1, 1, 1, 1 };
            a = new double[5] { 1, 1, 1, 1, 1 };
            standard = 0;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //Funciones para aplicar filtros Notch
        //1. SetNotch50: aplica un filtro notch a 50 Hz.
        public static double[] SetNotch50(double[] Data)
        {
            b2 = new double[5] { 0.96508099, -1.19328255, 2.29902305, -1.19328255, 0.96508099 };
            a2 = new double[5] { 1, -1.21449347931898, 2.29780334191380, -1.17207162934772, 0.931381682126902 };
            notch = 1;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //2. SetNotch60: aplica un filtro notch a 60 Hz.
        public static double[] SetNotch60(double[] Data)
        {
            b2 = new double[5] { 0.9650809863447347, -0.2424683201757643, 1.945391494128786, -0.2424683201757643, 0.9650809863447347 };
            a2 = new double[5] { 1, -0.2467782611297853, 1.944171784691352, -0.2381583792217435, 0.9313816821269039 };
            notch = 2;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //3. SetNotch60: quita el filtro tipo notch.
        public static double[] SetZNotch(double[] Data)
        {
            b2 = new double[5] { 1, 1, 1, 1, 1 };
            a2 = new double[5] { 1, 1, 1, 1, 1 };
            notch = 0;
            for (int i = 0; i < 8; i++)
            {
                Data[i + 1] = Filters.FiltersSelect(standard, notch, Data[i + 1], i);
            }

            return Data;
        }
        //Filtros para límitar la amplitud del voltaje 

        //Filtros para otras cosas
    }
}
