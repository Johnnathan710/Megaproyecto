﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBCI_GUI
{
    class Convert
    {
        public static int Bit16ToInt32(byte[] byteArray) // función para converstir los bytes de entrada de 16bit a un int32
        {
            int result = (
              ((0xFF & byteArray[0]) << 8) |
               (0xFF & byteArray[1])
              ); // la operanción es (1111 1111 AND Byte No.1 de la entrada) con un left shift de 8 casiilas
            // OR (1111 1111 AND  Byte No.2 de la entrada); el resultado se almacena en el int32 Result
            if ((result & 0x00008000) > 0) // condción No.1 (se revisa solo el primer bit, para ver si es mayor que 0
            {
                result = (int)((uint)result | (uint)0xFFFF0000); // operación es OR con 16 bits de 1's y 16 de 0's, con el resultado

            }
            else // si no se cumple
            {
                result = (int)((uint)result & (uint)0x0000FFFF); // se toman solo los ultimos 16 bits, ya que se hace un AND con 16 bits 0's y 16 bits 1's
            }
            return result; // retorno del valor
        }

        public static int Bit24ToInt32(byte[] byteArray) // función similar para pasar de 24 bits a 32 bits
        {
            int result = (
                 ((0xFF & byteArray[0]) << 16) |  // or del primer byte(corrido 16 espacios) con el segundo byte (corrido 8 espacios) y el utlimo byte
                 ((0xFF & byteArray[1]) << 8) |
                 (0xFF & byteArray[2])
               );
            if ((result & 0x00800000) > 0) // se revisa si el primer byte es mayor o menor que cero
            {
                result = (int)((uint)result | (uint)0xFF000000); // si se da este caso se hace un or para agregar el byte restante
            }
            else
            {
                result = (int)((uint)result & (uint)0x00FFFFFF); // se agrega un byte de 0's
            }
            return result;
        }
        // variables
        static double[] ConvertedData = new double[12]; // Array de doubles para almacenar la conversión
        private static int localByteCounter = 0; // contador del número de byte
        private static int localChannelCounter = 0; // contador del canal de entrada
        private static int PACKET_readstate = 0; // estado de la electura
        private static byte[] localAdsByteBuffer = { 0, 0, 0 }; // array de bytes para agregar al buffer
        private static byte[] localAccelByteBuffer = { 0, 0 };  // array de bytes para el buffer

        public static double[] interpretBinaryStream(byte actbyte) // función de interpretación
        {
            bool flag_copyRawDataToFullData = false; // bandera de proceso de conversión completo

            switch (PACKET_readstate) // Ciclo que siguen los datos para ser convertidos
            {
                case 0: //inicio del proctocolo de comunicación
                    if (actbyte == 0xC0)
                    {          // buscando el inicio del paquete
                        PACKET_readstate++;
                    }
                    break;
                case 1:
                    if (actbyte == 0xA0)
                    {          // buscando el inicio del paquete
                        PACKET_readstate++;
                    }
                    else
                    {
                        PACKET_readstate = 0;
                    }
                    break; // si se cumplen ambos, se procede a la siguiente fase
                case 2:
                    localByteCounter = 0; // se está analizando el primer byte
                    localChannelCounter = 0; // el primero canal
                    ConvertedData[localChannelCounter] = actbyte; // se recibe la data que está en el byte actual
                    localChannelCounter++; // se aumenta el contador de canal y el estado de lectura
                    PACKET_readstate++;
                    break;
                case 3:
                    localAdsByteBuffer[localByteCounter] = actbyte;  // en esta fase se leen los siguientes tres canales
                    localByteCounter++;
                    if (localByteCounter == 3) // cuando ya se contaron 3 bytes se procede a....
                    {
                        ConvertedData[localChannelCounter] = Bit24ToInt32(localAdsByteBuffer); // convertir estos tres bytes a un int32
                        localChannelCounter++; // se aumenta el contador de canales
                        if (localChannelCounter == 9) // cuando ya se contaron los 8 canales
                        {
                            PACKET_readstate++; // se puede pasar al siguiente estado, y se reinicia el contador de bytes
                            localByteCounter = 0;
                        }
                        else // si esto no se cumple solo se reinicia el contador de bytes
                        {
                            localByteCounter = 0;
                        }
                    }
                    break;
                case 4: // fase 5
                    localAccelByteBuffer[localByteCounter] = actbyte; // se alamacena el byte actual en el array del buffer
                    localByteCounter++; // se aumenta el contador de bytes
                    if (localByteCounter == 2) // al llegar al segundo se puede utilizar la función de 16bits a 32 bits
                    {
                        ConvertedData[localChannelCounter] = Bit16ToInt32(localAccelByteBuffer); //se alamacenan los datos convertidos
                        localChannelCounter++; // se aumenta el contador de canales
                        if (localChannelCounter == 12) // hasta llegar a los 12 canales
                        {
                            PACKET_readstate++; // si esto se cumple se reinicia el contador de bytes y se procede a la ultima fase
                            localByteCounter = 0;
                        }
                        else
                        {
                            localByteCounter = 0;
                        }
                    }
                    break;
                case 5: // se verifica que entre el byte final del protocolo
                    if (actbyte == 0xC0)
                    {
                        flag_copyRawDataToFullData = true; // se enciende la bandera 
                        PACKET_readstate = 1; //se establece el valor uno para seguir con la comunicación
                    }
                    else
                    {
                        PACKET_readstate = 0; // si hay un problema se reunicia el protocolo
                    }

                    break;
                default:
                    PACKET_readstate = 0; 
                    break;
            }

            if (flag_copyRawDataToFullData) // si se cumple la condición de la bandera, se procede a enviar los datos convertidos
            {
                flag_copyRawDataToFullData = false;
                return ConvertedData;
            }
            else
            {
                return null;
            }
        }
    }
}
