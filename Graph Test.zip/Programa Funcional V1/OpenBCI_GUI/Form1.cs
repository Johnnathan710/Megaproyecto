﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
// Utilizada para generar las señales sinusoidales. 
using MathNet.Numerics;
// Usada para realizar la FFT
using MathNet.Numerics.IntegralTransforms;
// para los números complejos
using System.Numerics;
// para generar las graficas
using System.Windows.Forms.DataVisualization.Charting;

namespace OpenBCI_GUI
{
    public partial class Form1 : Form
    {
        StreamWriter sw; // Se usa para escribir los caracteres de una secuencia en una forma determianda
        bool HSW = false; // presencia de steamwrite

        Complex[] samples = new Complex[256]; // Arrays que almacenan las 256 muestras
        Complex[] samples2 = new Complex[256];
        Complex[] samples3 = new Complex[256];
        Complex[] samples4 = new Complex[256];
        Complex[] samples5 = new Complex[256];
        Complex[] samples6 = new Complex[256];
        Complex[] samples7 = new Complex[256];
        Complex[] samples8 = new Complex[256];

        double[] Data2 = new double[256]; // Arrays para almacenar la interpretación de los datos
        double[] Data3 = new double[256];
        double[] Data4 = new double[256];
        double[] Data5 = new double[256];
        double[] Data6 = new double[256];
        double[] Data7 = new double[256];
        double[] Data8 = new double[256];
        double[] Data9 = new double[256];

        Boolean p = false; // Bandera de conteo de muestras
        Boolean visibleT = false; // Bandera para mostrar/ocultar gráficas de tiempo
        Boolean visibleF = false; // Bandera para mostrar/ocultar gráficas de freq
        int cont = 0; // Contador de las muestras

        int[] set = new int[] { 4, 1, 1, 1, 1, 1, 1, 1, 1 }; //Selección de canales

        public Form1()
        {
            InitializeComponent();  //Inicialización

            foreach (string s in SerialPort.GetPortNames()) // se agregan los posibles puestos COM a la lista
            {
                comboBox1.Items.Add(s); 
            }
            comboBox1.SelectedItem = "COM16"; // Estados iniciales

            textBox2.Text = Application.StartupPath; 
            textBox3.Text = "test.txt";

            radioButton4.Checked = true;
            radioButton5.Checked = true;
            radioButton8.Checked = true;

            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;

            checkBox1.Checked = true;
            checkBox2.Checked = true;
            checkBox3.Checked = true;
            checkBox4.Checked = true;
            checkBox5.Checked = true;
            checkBox6.Checked = true;
            checkBox7.Checked = true;
            checkBox8.Checked = true;
        }
        
        struct DataSerialPort
        {
            public byte[] Var; // array de bytes, que es parate de la estructura del DataSerialPort
        };

        Queue<DataSerialPort> driver = new Queue<DataSerialPort>(); // inicialización del driver de tipo DSP


        void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e) //función de 
        {
            DataSerialPort received_Data; // DSP para las entradas
            byte[] buffer = new byte[serialPort1.BytesToRead]; //array de bytes con los datos de entrada
            serialPort1.Read(buffer, 0, buffer.Length); //lectura del puerto
            received_Data.Var = buffer; //Se almacena el buffer en la variable DSP
            driver.Enqueue(received_Data); //se agregan la entrada recibida al driver que contiene todos los datos
        }

        private void button1_Click(object sender, EventArgs e) // OpenPort
        {
            serialPort1.PortName = comboBox1.Text; // selección del puerto
            serialPort1.BaudRate = 115200; // se establece el Baudrate
            try
            {
                serialPort1.Open(); // se intenta abrir el puerto para la conexión
                button1.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = true;
            }
            catch
            {
                MessageBox.Show("No se puede abrir el puerto " + comboBox1.Text.ToString());
            }
            serialPort1.DataReceived += serialPort1_DataReceived;  // se agrega la data de entrada a la que ya se tiene
        }

        private void button2_Click(object sender, EventArgs e) //close port
        {
            turnOFF_SW();  // se corta la transmición de datos y se cierra el puerto
            turnOFF_transmision();
            serialPort1.Close();
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e) //Start Stream
        {
            char[] buff = new char[1]; //array de chars
            buff[0] = 'b'; // es el caracter que se envia para inciar la comuniación (protocolo de OPENBCI)
            try
            {
                serialPort1.Write(buff, 0, 1);
            }
            catch
            {
                MessageBox.Show("No se puede ejecutar");
            }
            button3.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e) // Stop Stream
        {
            turnOFF_SW();
            turnOFF_transmision();
            button4.Enabled = false;
            button3.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e) //Write to File
        {
            try
            {
                Directory.CreateDirectory(textBox2.Text);
                sw = new StreamWriter(Path.Combine(textBox2.Text, textBox3.Text));
                HSW = true;
            }
            catch
            {
                MessageBox.Show("El directorio no se puede crear directamente en la partición principal.");
            }
            button5.Enabled = false;
            button6.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e) // Stop Write
        {
            turnOFF_SW();
            button5.Enabled = true;
            button6.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e) //timer Tick
        {
            if(checkBox1.Checked == false) //verificación de la gráfica del canal No.1
            {
                set[1] = 0;
                chart2.Visible = false;
                chart10.Visible = false;
            }
            else
            {
                set[1] = 1;
                if(visibleT == false) { 
                chart2.Visible = true;
                }
                if(visibleF == false) { 
                chart10.Visible = true;
                }
            }
            if (checkBox2.Checked == false) //verificación de la gráfica del canal No.2
            {
                set[2] = 0;
                chart3.Visible = false;
                chart11.Visible = false;
            }
            else
            {
                set[2] = 1;
                if (visibleT == false)
                {
                    chart3.Visible = true;
                }
                if (visibleF == false)
                {
                    chart11.Visible = true;
                }
            }
            if (checkBox3.Checked == false) //verificación de la gráfica del canal No.3
            {
                set[3] = 0;
                chart4.Visible = false;
                chart1.Visible = false;
            }
            else
            {
                set[3] = 1;
                if (visibleT == false)
                {
                    chart4.Visible = true;
                }
                if (visibleF == false)
                {
                    chart1.Visible = true;
                }
            }
            if (checkBox4.Checked == false) //verificación de la gráfica del canal No.4
            {
                set[4] = 0;
                chart5.Visible = false;
                chart12.Visible = false;
            }
            else
            {
                set[4] = 1;
                if (visibleT == false)
                {
                    chart5.Visible = true;
                }
                if (visibleF == false)
                {
                    chart12.Visible = true;
                }
            }
            if (checkBox5.Checked == false) //verificación de la gráfica del canal No.5
            {
                set[5] = 0;
                chart6.Visible = false;
                chart13.Visible = false;
            }
            else
            {
                set[5] = 1;
                if (visibleT == false)
                {
                    chart6.Visible = true;
                }
                if (visibleF == false)
                {
                    chart13.Visible = true;
                }
            }
            if (checkBox6.Checked == false) //verificación de la gráfica del canal No.6
            {
                set[6] = 0;
                chart7.Visible = false;
                chart14.Visible = false;
            }
            else
            {
                set[6] = 1;
                if (visibleT == false)
                {
                    chart7.Visible = true;
                }
                if (visibleF == false)
                {
                    chart14.Visible = true;
                }
            }
            if (checkBox7.Checked == false) //verificación de la gráfica del canal No.7
            {
                set[7] = 0;
                chart8.Visible = false;
                chart15.Visible = false;
            }
            else
            {
                set[7] = 1;
                if (visibleT == false)
                {
                    chart8.Visible = true;
                }
                if (visibleF == false)
                {
                    chart15.Visible = true;
                }
            }
            if (checkBox8.Checked == false) //verificación de la gráfica del canal No.8
            {
                set[8] = 0;
                chart9.Visible = false;
                chart16.Visible = false;
            }
            else
            {
                set[8] = 1;
                if (visibleT == false)
                {
                    chart9.Visible = true;
                }
                if (visibleF == false)
                {
                    chart16.Visible = true;
                }
            }
            double[] DataLynx; //array de tipo double que contiene el bosquejo de los datos
            while (driver.Count > 0) //while con la condición de que la cantidad de elementos incluidos en Queue sea mayor que 0
            {
                DataSerialPort data = driver.Dequeue(); // se quita y devuelve el objeto al comienzo del Queue
                for (int g = 0; g < data.Var.Length; g++)  // ciclo para interpretar el byte de entrada
                {
                    DataLynx = Functions.interpretBinaryStream(data.Var[g]); //se utiliza la función del documento convert
                    //DataLynx es un array de 8 bytes que contienen la información de los canales
                    if (DataLynx != null) //con de que el valor de DataLynx sea correcta, se procede a la segunda parte del proceso
                    {
                        Boolean p = true; //Bandera inicio de ciclo
                        DataLynx = Functions.SetChannels(DataLynx, set, p);
                        //funciones descritas  abajo
                        Functions.writeToFile(DataLynx, HSW, sw); // Generar el archivo
                        drawPlot(DataLynx);
                    }
                }
            }

        }

        private void drawPlot(double[] Data) //función para graficar los resultados
        {
            Data = filtering(Data);

            // determinar cuantos Hz representa cada una de las muestras
            float hzPerSample = 250 / 256;

            if (p == false)
            {
                Data2[cont] = Functions.GetDataCH(p, Data, Data2, 1);
                Data3[cont] = Functions.GetDataCH(p, Data, Data3, 2);
                Data4[cont] = Functions.GetDataCH(p, Data, Data4, 3);
                Data5[cont] = Functions.GetDataCH(p, Data, Data5, 4);
                Data6[cont] = Functions.GetDataCH(p, Data, Data6, 5);
                Data7[cont] = Functions.GetDataCH(p, Data, Data7, 6);
                Data8[cont] = Functions.GetDataCH(p, Data, Data8, 7);
                Data9[cont] = Functions.GetDataCH(p, Data, Data9, 8);
                cont = Functions.GetCont(cont, p);
                if(cont == 0)
                {
                    p = Functions.CheckFlag(cont,p);
                }
            }
            
            if (p == true)
            {
                samples = Functions.GenerateComplex(p, Data2, samples);
                samples2 = Functions.GenerateComplex(p, Data3, samples2);
                samples3 = Functions.GenerateComplex(p, Data4, samples3);
                samples4 = Functions.GenerateComplex(p, Data5, samples4);
                samples5 = Functions.GenerateComplex(p, Data6, samples5);
                samples6 = Functions.GenerateComplex(p, Data7, samples6);
                samples7 = Functions.GenerateComplex(p, Data8, samples7);
                samples8 = Functions.GenerateComplex(p, Data9, samples8);

                chart10.Series["Freq"].Points.Clear();
                chart10.Series["Fase"].Points.Clear();

                chart11.Series["Freq"].Points.Clear();
                chart11.Series["Fase"].Points.Clear();

                chart12.Series["Freq"].Points.Clear();
                chart12.Series["Fase"].Points.Clear();

                chart13.Series["Freq"].Points.Clear();
                chart13.Series["Fase"].Points.Clear();

                chart14.Series["Freq"].Points.Clear();
                chart14.Series["Fase"].Points.Clear();

                chart15.Series["Freq"].Points.Clear();
                chart15.Series["Fase"].Points.Clear();

                chart16.Series["Freq"].Points.Clear();
                chart16.Series["Fase"].Points.Clear();

                chart1.Series["Freq"].Points.Clear();
                chart1.Series["Fase"].Points.Clear();
                // "Forward" Fourier convierte tiempo en freq
                samples = Functions.FFT(samples);
                samples2 = Functions.FFT(samples2);
                samples3 = Functions.FFT(samples3);
                samples4 = Functions.FFT(samples4);
                samples5 = Functions.FFT(samples5);
                samples6 = Functions.FFT(samples6);
                samples7 = Functions.FFT(samples7);

                for (int i = 1; i < samples.Length / 2; i++)
                {
                    chart10.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart10.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart10.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart10.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart10.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart11.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart11.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart11.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart11.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart11.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart1.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart1.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart1.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart1.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart1.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart12.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart12.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart12.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart12.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart12.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart13.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart13.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart13.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart13.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart13.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart14.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart14.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart14.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart14.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart14.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart15.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart15.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart15.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart15.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart15.ChartAreas["ChartArea1"].AxisY.Maximum = 50;

                    chart16.ChartAreas["ChartArea1"].AxisX.Title = "Hz";
                    chart16.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Arial", 14.0f);
                    chart16.ChartAreas["ChartArea1"].AxisX.MinorTickMark.Enabled = true;
                    chart16.ChartAreas["ChartArea1"].AxisX.Maximum = 50;
                    chart16.ChartAreas["ChartArea1"].AxisY.Maximum = 50;
                    // Se obitnee la magnitud de cada una de las muestras de la FFT:
                    //  = abs[sqrt(real^2 + imaginario^2)]
                    double mag = Functions.GetMagnitude(samples, i);
                    double mag2 = Functions.GetMagnitude(samples2, i);
                    double mag3 = Functions.GetMagnitude(samples3, i);
                    double mag4 = Functions.GetMagnitude(samples4, i);
                    double mag5 = Functions.GetMagnitude(samples5, i);
                    double mag6 = Functions.GetMagnitude(samples6, i);
                    double mag7 = Functions.GetMagnitude(samples7, i);
                    double mag8 = Functions.GetMagnitude(samples8, i);

                    chart10.Series["Freq"].Points.AddXY(hzPerSample * i, mag);
                    chart11.Series["Freq"].Points.AddXY(hzPerSample * i, mag2);
                    chart1.Series["Freq"].Points.AddXY(hzPerSample * i, mag3);
                    chart12.Series["Freq"].Points.AddXY(hzPerSample * i, mag4);
                    chart13.Series["Freq"].Points.AddXY(hzPerSample * i, mag5);
                    chart14.Series["Freq"].Points.AddXY(hzPerSample * i, mag6);
                    chart15.Series["Freq"].Points.AddXY(hzPerSample * i, mag7);
                    chart16.Series["Freq"].Points.AddXY(hzPerSample * i, mag8);
                }
                    
                    p = false;
                
            }
                chart2.Series[0].Points.Add(Data[1]);
                chart3.Series[0].Points.Add(Data[2]);
                chart4.Series[0].Points.Add(Data[3]);
                chart5.Series[0].Points.Add(Data[4]);
                chart6.Series[0].Points.Add(Data[5]);
                chart7.Series[0].Points.Add(Data[6]);
                chart8.Series[0].Points.Add(Data[7]);
                chart9.Series[0].Points.Add(Data[8]);

                while (chart2.Series[0].Points.Count > 1250)
                {

                    chart2.Series[0].Points.SuspendUpdates();
                    chart2.Series[0].Points.Remove(chart2.Series[0].Points.First());
                    chart2.Series[0].Points.ResumeUpdates();

                    chart3.Series[0].Points.SuspendUpdates();
                    chart3.Series[0].Points.Remove(chart3.Series[0].Points.First());
                    chart3.Series[0].Points.ResumeUpdates();

                    chart4.Series[0].Points.SuspendUpdates();
                    chart4.Series[0].Points.Remove(chart4.Series[0].Points.First());
                    chart4.Series[0].Points.ResumeUpdates();

                    chart5.Series[0].Points.SuspendUpdates();
                    chart5.Series[0].Points.Remove(chart5.Series[0].Points.First());
                    chart5.Series[0].Points.ResumeUpdates();

                    chart6.Series[0].Points.SuspendUpdates();
                    chart6.Series[0].Points.Remove(chart6.Series[0].Points.First());
                    chart6.Series[0].Points.ResumeUpdates();

                    chart7.Series[0].Points.SuspendUpdates();
                    chart7.Series[0].Points.Remove(chart7.Series[0].Points.First());
                    chart7.Series[0].Points.ResumeUpdates();

                    chart8.Series[0].Points.SuspendUpdates();
                    chart8.Series[0].Points.Remove(chart8.Series[0].Points.First());
                    chart8.Series[0].Points.ResumeUpdates();

                    chart9.Series[0].Points.SuspendUpdates();
                    chart9.Series[0].Points.Remove(chart9.Series[0].Points.First());
                    chart9.Series[0].Points.ResumeUpdates();
                }
        }


        private double[] filtering(double[] Data) //función para agregar los filtros, el proceso de esta se detalla en el archivo filters
        {
            int standard = 0;
            int notch = 0;

            if (radioButton5.Checked)
            {
                notch = 0;
                Data = Functions.SetZNotch(Data);
            }
            else if (radioButton6.Checked)
            {
                notch = 1;
                Data = Functions.SetNotch50(Data);
            }
            else if (radioButton7.Checked)
            {
                notch = 2;
                Data = Functions.SetNotch60(Data);
            }
            if (radioButton8.Checked)
            {
                standard = 0;
                Data = Functions.SetNone(Data);
            }
            if (radioButton9.Checked)
            {
                standard = 1;
                Data = Functions.SetAll(Data);
            }
            if (radioButton10.Checked)
            {
                standard = 2;
                Data = Functions.SetAlpha(Data);
            }
            if (radioButton11.Checked)
            {
                standard = 3;
                Data = Functions.SetBeta(Data);
            }
            if (radioButton12.Checked)
            {
                standard = 4;
                Data = Functions.SetGandD(Data);
            }
            return Data;
        }

        private void turnOFF_SW()  //función para cerrar el puerto
        {
            if (HSW)
            {
                HSW = false;
                sw.Close();
            }
        }

        private void turnOFF_transmision() //función para parar la transmisión
        {
            char[] buff = new char[1];
            buff[0] = 's';
            serialPort1.Write(buff, 0, 1);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //-1V 1V
            chart2.ChartAreas[0].AxisY.Maximum = 1000000;
            chart2.ChartAreas[0].AxisY.Minimum = -1000000;

            chart3.ChartAreas[0].AxisY.Maximum = 1000000;
            chart3.ChartAreas[0].AxisY.Minimum = -1000000;

            chart4.ChartAreas[0].AxisY.Maximum = 1000000;
            chart4.ChartAreas[0].AxisY.Minimum = -1000000;

            chart5.ChartAreas[0].AxisY.Maximum = 1000000;
            chart5.ChartAreas[0].AxisY.Minimum = -1000000;

            chart6.ChartAreas[0].AxisY.Maximum = 1000000;
            chart6.ChartAreas[0].AxisY.Minimum = -1000000;

            chart7.ChartAreas[0].AxisY.Maximum = 1000000;
            chart7.ChartAreas[0].AxisY.Minimum = -1000000;

            chart8.ChartAreas[0].AxisY.Maximum = 1000000;
            chart8.ChartAreas[0].AxisY.Minimum = -1000000;

            chart9.ChartAreas[0].AxisY.Maximum = 1000000;
            chart9.ChartAreas[0].AxisY.Minimum = -1000000;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //-100mV 100mV
            chart2.ChartAreas[0].AxisY.Maximum = 100000;
            chart2.ChartAreas[0].AxisY.Minimum = -100000;

            chart3.ChartAreas[0].AxisY.Maximum = 100000;
            chart3.ChartAreas[0].AxisY.Minimum = -100000;

            chart4.ChartAreas[0].AxisY.Maximum = 100000;
            chart4.ChartAreas[0].AxisY.Minimum = -100000;

            chart5.ChartAreas[0].AxisY.Maximum = 100000;
            chart5.ChartAreas[0].AxisY.Minimum = -100000;

            chart6.ChartAreas[0].AxisY.Maximum = 100000;
            chart6.ChartAreas[0].AxisY.Minimum = -100000;

            chart7.ChartAreas[0].AxisY.Maximum = 100000;
            chart7.ChartAreas[0].AxisY.Minimum = -100000;

            chart8.ChartAreas[0].AxisY.Maximum = 100000;
            chart8.ChartAreas[0].AxisY.Minimum = -100000;

            chart9.ChartAreas[0].AxisY.Maximum = 100000;
            chart9.ChartAreas[0].AxisY.Minimum = -100000;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //-10mv 10mv
            chart2.ChartAreas[0].AxisY.Maximum = 10000;
            chart2.ChartAreas[0].AxisY.Minimum = -10000;

            chart3.ChartAreas[0].AxisY.Maximum = 10000;
            chart3.ChartAreas[0].AxisY.Minimum = -10000;

            chart4.ChartAreas[0].AxisY.Maximum = 10000;
            chart4.ChartAreas[0].AxisY.Minimum = -10000;

            chart5.ChartAreas[0].AxisY.Maximum = 10000;
            chart5.ChartAreas[0].AxisY.Minimum = -10000;

            chart6.ChartAreas[0].AxisY.Maximum = 10000;
            chart6.ChartAreas[0].AxisY.Minimum = -10000;

            chart7.ChartAreas[0].AxisY.Maximum = 10000;
            chart7.ChartAreas[0].AxisY.Minimum = -10000;

            chart8.ChartAreas[0].AxisY.Maximum = 10000;
            chart8.ChartAreas[0].AxisY.Minimum = -10000;

            chart9.ChartAreas[0].AxisY.Maximum = 10000;
            chart9.ChartAreas[0].AxisY.Minimum = -10000;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //-1mV
            chart2.ChartAreas[0].AxisY.Maximum = 1000;
            chart2.ChartAreas[0].AxisY.Minimum = -1000;

            chart3.ChartAreas[0].AxisY.Maximum = 1000;
            chart3.ChartAreas[0].AxisY.Minimum = -1000;

            chart4.ChartAreas[0].AxisY.Maximum = 1000;
            chart4.ChartAreas[0].AxisY.Minimum = -1000;

            chart5.ChartAreas[0].AxisY.Maximum = 1000;
            chart5.ChartAreas[0].AxisY.Minimum = -1000;

            chart6.ChartAreas[0].AxisY.Maximum = 1000;
            chart6.ChartAreas[0].AxisY.Minimum = -1000;

            chart7.ChartAreas[0].AxisY.Maximum = 1000;
            chart7.ChartAreas[0].AxisY.Minimum = -1000;

            chart8.ChartAreas[0].AxisY.Maximum = 1000;
            chart8.ChartAreas[0].AxisY.Minimum = -1000;

            chart9.ChartAreas[0].AxisY.Maximum = 1000;
            chart9.ChartAreas[0].AxisY.Minimum = -1000;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(comboBox2.Text == "Tiempo")
            {
                visibleT = true;
                chart2.Visible = false;
                chart3.Visible = false;
                chart4.Visible = false;
                chart5.Visible = false;
                chart6.Visible = false;
                chart7.Visible = false;
                chart8.Visible = false;
                chart9.Visible = false;
            }
            if (comboBox2.Text == "Frecuencia")
            {
                visibleF = true;
                chart1.Visible = false;
                chart10.Visible = false;
                chart11.Visible = false;
                chart12.Visible = false;
                chart13.Visible = false;
                chart14.Visible = false;
                chart15.Visible = false;
                chart16.Visible = false;
            }
            button9.Enabled = true;
            button8.Enabled = false;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "Tiempo")
            {
                visibleT = false;
                chart2.Visible = true;
                chart3.Visible = true;
                chart4.Visible = true;
                chart5.Visible = true;
                chart6.Visible = true;
                chart7.Visible = true;
                chart8.Visible = true;
                chart9.Visible = true;
            }
            if (comboBox2.Text == "Frecuencia")
            {
                visibleF = false;
                chart1.Visible = true;
                chart10.Visible = true;
                chart11.Visible = true;
                chart12.Visible = true;
                chart13.Visible = true;
                chart14.Visible = true;
                chart15.Visible = true;
                chart16.Visible = true;
            }
            button9.Enabled = false;
            button8.Enabled = true;
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            //-100uV
            chart2.ChartAreas[0].AxisY.Maximum = 100;
            chart2.ChartAreas[0].AxisY.Minimum = -100;

            chart3.ChartAreas[0].AxisY.Maximum = 100;
            chart3.ChartAreas[0].AxisY.Minimum = -100;

            chart4.ChartAreas[0].AxisY.Maximum = 100;
            chart4.ChartAreas[0].AxisY.Minimum = -100;

            chart5.ChartAreas[0].AxisY.Maximum = 100;
            chart5.ChartAreas[0].AxisY.Minimum = -100;

            chart6.ChartAreas[0].AxisY.Maximum = 100;
            chart6.ChartAreas[0].AxisY.Minimum = -100;

            chart7.ChartAreas[0].AxisY.Maximum = 100;
            chart7.ChartAreas[0].AxisY.Minimum = -100;

            chart8.ChartAreas[0].AxisY.Maximum = 100;
            chart8.ChartAreas[0].AxisY.Minimum = -100;

            chart9.ChartAreas[0].AxisY.Maximum = 100;
            chart9.ChartAreas[0].AxisY.Minimum = -100;
        }
        
    }
}
